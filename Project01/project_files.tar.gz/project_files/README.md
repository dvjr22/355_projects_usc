# Diego Valdes
# CSCE 355
# Nov 21, 2017

Please use the interpreted script

Completed for normal credit:
Simulating a DFA
Closure properties: complement and intersection

Completed for extra credit:
Text search
